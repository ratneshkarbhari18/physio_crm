<div class="sidebar" data-color="grey" data-image="../assets/img/sidebar-5.jpg">
    	<div class="sidebar-wrapper">
        <div class="logo">
            <center>
            <a href="dashboard.php" class="simple-text logo-normal">
                <img src="../assets/img/logo.png" style="width:60%;"/>
            </a>
            </center>
        </div>
			<div class="user">
				<div class="info">
					<div class="photo">
	                    <img src="../assets/img/woman.png" />
	                </div>

					<a data-toggle="collapse" href="#collapseExample" class="collapsed">
						<span>
							<?php echo $_SESSION['billing_name']?>
						</span>
                    </a>


				</div>
            </div>

            <ul class="nav">

                <li class="nav-item" id="nav-dashboard">
                    <a class="nav-link" href="dashboard.php">
                        <i class="nc-icon nc-notes"></i>
                        <p>Unpaid Bills
                        </p>
                    </a>
                </li>

				<li class="nav-item" id="nav-paid">
					<a class="nav-link" href="paid.php">
						<i class="nc-icon nc-single-copy-04"></i>
						<p>Paid Bills
						</p>
					</a>
				</li>
        <li class="nav-item" id="nav-cons">
            <a class="nav-link" href="cons_bills.php">
                <i class="nc-icon nc-notes"></i>
                <p>Consultant Unpaid Bills
                </p>
            </a>
        </li>

      <li class="nav-item" id="nav-cons_paid">
      <a class="nav-link" href="cons_paid.php">
        <i class="nc-icon nc-single-copy-04"></i>
        <p>Consultant Paid Bills
        </p>
      </a>
      </li>
				<li class="nav-item" id="nav-donation">
					<a class="nav-link" href="donation.php">
						<i class="nc-icon nc-money-coins"></i>
						<p>Donation
						</p>
					</a>
				</li>
				<li class="nav-item" id="nav-voucher">
					<a class="nav-link" href="voucher.php">
						<i class="nc-icon nc-paper-2"></i>
						<p>Vouchers
						</p>
					</a>
				</li>
				<li class="nav-item" id="nav-doc">
					<a class="nav-link" href="doc-sal.php">
						<i class="nc-icon nc-paper-2"></i>
						<p>Doctor Renumeration
						</p>
					</a>
				</li>
				<li class="nav-item" id="nav-staff">
					<a class="nav-link" href="staff-sal.php">
						<i class="nc-icon nc-paper-2"></i>
						<p>Staff Renumeration
						</p>
					</a>
				</li>
				<li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="nc-icon nc-button-power"></i>
                            <p>Logout</p>
                        </a>
                    </li>

            </ul>
    	</div>
    </div>
