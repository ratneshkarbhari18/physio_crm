<?php 
//connect.php;
$con = mysqli_connect("localhost", "root", "6s8kGa3SvGFJm4kN", "hospital") or die("Cannot Connect To The Database");
?>
